﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloAPI;
using System.IO;

namespace HelloWorldUnitTest
{
    [TestClass]
    public class UnitTest
    {
        /*
         * This is a unit test that intercepts the console output to assert that the expected string is being printed. 
         */
        [TestMethod]
        public void TestHelloWorldConsole()
        {
            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);

                var helloWorldConsole = new HelloWorldConsole();

                helloWorldConsole.WriteHelloWorld();

                string expected = string.Format("Hello, world!{0}Press any key to exit.", Environment.NewLine);

                Assert.AreEqual<string>(expected, sw.ToString());
            }
        }
    }
}
