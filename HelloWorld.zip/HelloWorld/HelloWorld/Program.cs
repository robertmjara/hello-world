﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Specialized;
using HelloAPI;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 
            Hello, and welcome to my hello world program.

            To print "Hello, world!" to the console, the "platform" key in App.config must be set to the value "console".
            To display an HTML page with the same message, this value must be set to "web"
             */
            string platform = ConfigurationManager.AppSettings.Get("platform");

            var api = HelloAPI.HelloAPI.Create(platform);
            api.WriteHelloWorld();
        }
    }
}
