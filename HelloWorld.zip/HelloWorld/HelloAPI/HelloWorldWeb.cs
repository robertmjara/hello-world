﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloAPI
{
    public class HelloWorldWeb : HelloAPI
    {
        public override void WriteHelloWorld()
        {
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory) + "/HelloWorldWeb.html";
            info.UseShellExecute = true;
            Process.Start(info);
        }
    }
}
