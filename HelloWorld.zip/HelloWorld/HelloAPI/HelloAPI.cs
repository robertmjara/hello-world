﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloAPI
{
    public abstract class HelloAPI
    {
        public static HelloAPI Create(string platform)
        {
            if (platform == "console")
                return new HelloWorldConsole();
            else if (platform == "web")
                return new HelloWorldWeb();
            else
                throw new Exception("Unsupported platform specified in App.Config");
        }

        public abstract void WriteHelloWorld();
    }
}
