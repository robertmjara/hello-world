﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloAPI
{
    public class HelloWorldConsole : HelloAPI
    {
        public override void WriteHelloWorld()
        {
            Console.Write("Hello, world!");
            Console.WriteLine();
            Console.Write("Press any key to exit.");
            Console.Read();
        }
    }
}
